package com.cg.ems.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class TestManyToManyDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Product p1=new Product();
		p1.setProductcode(100);
		p1.setProname("TV");
		p1.setProprice(54000);
		
		Product p2=new Product();
		p2.setProductcode(200);
		p2.setProname("AC");
		p2.setProprice(65000);
		
		Product p3=new Product();
		p3.setProductcode(300);
		p3.setProname("Refrigerator");
		p3.setProprice(20000);
		
		Supplier sony=new Supplier();
		sony.setSupplierid(101);
		sony.setSupplyDate(new Date(2018,12,04));
		
		Supplier lg=new Supplier();
		lg.setSupplierid(102);
		lg.setSupplyDate(new Date(2014,10,12));
		
		Set<Product> electset=new HashSet<Product>();
		electset.add(p1);
		electset.add(p1);
		electset.add(p3);
		Set<Supplier> suppset=new HashSet<Supplier>();
		suppset.add(sony);
		suppset.add(lg);
		
		p1.setSupSet(suppset);
		sony.setProSet(electset);
		et.begin();
		
		em.persist(sony);
		em.persist(lg);
		et.commit();
		System.out.println("product is persisted");
		
		
	}

}
