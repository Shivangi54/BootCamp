package com.cg.ems.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="supplier_master")
public class Supplier {
	@Id
	@Column(name="supp_id",length=10)
	private int supplierid;
	@Temporal(value = TemporalType.DATE)
	private Date supplyDate;
	public int getSupplierid() {
		return supplierid;
	}
	public void setSupplierid(int supplierid) {
		this.supplierid = supplierid;
	}
	public Date getSupplyDate() {
		return supplyDate;
	}
	public void setSupplyDate(Date supplyDate) {
		this.supplyDate = supplyDate;
	}
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="pro_supply",joinColumns= {@JoinColumn(name="supp_id")},inverseJoinColumns={@JoinColumn(name="pro_id")})
	Set<Product> proSet=new HashSet<Product>();
	public Set<Product> getProSet() {
		return proSet;
	}
	public void setProSet(Set<Product> proSet) {
		this.proSet = proSet;
	}
	public Supplier() {
		super();
		
	}
	public Supplier(int supplierid, Date supplyDate) {
		super();
		this.supplierid = supplierid;
		this.supplyDate = supplyDate;
	}
	@Override
	public String toString() {
		return "Supplier [supplierid=" + supplierid + ", supplyDate=" + supplyDate + "]";
	}
	
}
