package com.cg.ems.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="product_master")
public class Product {
	@Id
	@Column(name="pro_id",length=10)
	private int productcode;
	@Column(name="pro_name",length=20)
	private String proname;
	@Column(name="pro_price",length=10)
	private float proprice;
	public int getProductcode() {
		return productcode;
	}
	public void setProductcode(int productcode) {
		this.productcode = productcode;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public float getProprice() {
		return proprice;
	}
	public void setProprice(float proprice) {
		this.proprice = proprice;
	}
	@ManyToMany(mappedBy="proSet")
	Set<Supplier> supSet=new HashSet<Supplier>();
	public Product() {
		super();
		
	}
	public Set<Supplier> getSupSet() {
		return supSet;
	}
	public void setSupSet(Set<Supplier> supSet) {
		this.supSet = supSet;
	}
	public Product(int productcode, String proname, float proprice) {
		super();
		this.productcode = productcode;
		this.proname = proname;
		this.proprice = proprice;
	}
	@Override
	public String toString() {
		return "Product [productcode=" + productcode + ", proname=" + proname + ", proprice=" + proprice + "]";
	}
	

}
