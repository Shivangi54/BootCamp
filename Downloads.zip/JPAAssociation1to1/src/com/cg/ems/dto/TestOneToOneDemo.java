package com.cg.ems.dto;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Address vAddress=new Address();
		vAddress.setCity("pune");
		vAddress.setState("maha");
		vAddress.setStreet("talwade");
		vAddress.setZipcode("411024");

		Address tAddress=new Address();
		tAddress.setCity("aligarh");
		tAddress.setState("up");
		tAddress.setStreet("civil lines");
		tAddress.setZipcode("202001");
		
		Address pAddress=new Address();
		pAddress.setCity("allahabad");
		pAddress.setState("up");
		pAddress.setStreet("avas vikas");
		pAddress.setZipcode("210985");
		
		Address rAddress=new Address();
		rAddress.setCity("noida");
		rAddress.setState("up");
		rAddress.setStreet("city");
		rAddress.setZipcode("210845");
		
		Student rishu=new Student();
		rishu.setName("rishu sharma");
		rishu.setStuAddress(rAddress);
		
		Student pihu=new Student();
		pihu.setName("pihu dixit");
		pihu.setStuAddress(pAddress);
		
		Student tani=new Student();
		tani.setName("tani tiwari");
		tani.setStuAddress(tAddress);
		
		Student chinu=new Student();
		chinu.setName("chinu gupta");
		chinu.setStuAddress(vAddress);
		
		et.begin();
		em.persist(rishu);
		em.persist(chinu);
		em.persist(pihu);
		em.persist(tani);
		et.commit();
		System.out.println("data is inserted");
		System.out.println("-----------------Fetch-----------------");
		Student st=em.find(Student.class, 59);
		System.out.println(st);
		et.begin();
		em.remove(st);
		et.commit();
		System.out.println("deleted");
		
		
	}

}
