package com.cg.ems.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="dept_master")
public class Department {
	@Id
	@Column(name="dept_code",length=10)
	private int deptcode;
	@Column(name="dept_name",length=20)
	private String deptname;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="empDept")
	private Set<Employee> empSet=new HashSet<Employee>();
	
	

	public Set<Employee> getEmpSet() {
		return empSet;
	}
	public void setEmpSet(Set<Employee> empSet) {
		this.empSet = empSet;
	}
	public int getDeptcode() {
		return deptcode;
	}
	public void setDeptcode(int deptcode) {
		this.deptcode = deptcode;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	@Override
	public String toString() {
		return "Department [deptcode=" + deptcode + ", deptname=" + deptname + "]";
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(int deptcode, String deptname) {
		super();
		this.deptcode = deptcode;
		this.deptname = deptname;
	}
	
}
