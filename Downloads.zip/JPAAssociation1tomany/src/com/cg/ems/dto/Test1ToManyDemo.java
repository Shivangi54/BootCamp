package com.cg.ems.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.util.JPAUtil;

public class Test1ToManyDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Department d1=new Department();
		d1.setDeptcode(101);
		d1.setDeptname("accounts");
		
		Department d2=new Department();
		d2.setDeptcode(102);
		d2.setDeptname("marketing");
		
		Employee e1=new Employee();
		e1.setEmpName("ramya");
		e1.setEmpId(201);
		e1.setEmpSal(34000);
		e1.setEmpDept(d1);

		Employee e2=new Employee();
		e2.setEmpName("shivi");
		e2.setEmpId(202);
		e2.setEmpSal(35000);
		e2.setEmpDept(d2);

		Employee e3=new Employee();
		e3.setEmpName("ankii");
		e3.setEmpId(203);
		e3.setEmpSal(29000);
		e3.setEmpDept(d1);
		
		Employee e4=new Employee();
		e4.setEmpName("pc");
		e4.setEmpId(204);
		e4.setEmpSal(26000);
		e4.setEmpDept(d2);
	
		Set<Employee> adminEmpSet=new HashSet<Employee>();
		adminEmpSet.add(e1);
		adminEmpSet.add(e2);
		
		Set<Employee> saleEmpSet=new HashSet<Employee>();
		saleEmpSet.add(e3);
		saleEmpSet.add(e4);
		d1.setEmpSet(adminEmpSet);
		d2.setEmpSet(saleEmpSet);
		et.begin();
		em.persist(d1);
		em.persist(d2);
		et.commit();
		System.out.println("inserted");
	
	}
		
				
	}	
	

